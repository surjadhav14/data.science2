"""
Data Cleaning, Processing & Visualization Pipeline
--------------------------------------------------
Usage:  python data_cleaning_dashboard.py [path_to_csv]
Default dataset: Titanic (raw, with missing values / outliers / duplicates).
Outputs: cleaned_data.csv, dashboard.png, cleaning_report.txt
"""
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

PATH = sys.argv[1] if len(sys.argv) > 1 else "raw.csv"
sns.set_theme(style="whitegrid", palette="deep")
report = []

def log(msg):
    print(msg)
    report.append(msg)

# ---------------------------------------------------------------- 1. LOAD
df = pd.read_csv(PATH)
log(f"[LOAD] shape = {df.shape}")
log(f"[LOAD] dtypes:\n{df.dtypes.to_string()}\n")

# ---------------------------------------------------------------- 2. DUPLICATES
n_dup = df.duplicated().sum()
df = df.drop_duplicates().reset_index(drop=True)
log(f"[DUPLICATES] removed {n_dup} exact duplicate rows -> {df.shape}")

# ---------------------------------------------------------------- 3. MISSING VALUES
miss = df.isna().sum()
miss_pct = (miss / len(df) * 100).round(1)
log("[MISSING] before cleaning:\n" +
    pd.DataFrame({"missing": miss, "pct": miss_pct})[miss > 0].to_string())

# Strategy: drop columns >50% missing; median for numeric; mode for categorical
drop_cols = miss_pct[miss_pct > 50].index.tolist()
df = df.drop(columns=drop_cols)
log(f"[MISSING] dropped columns (>50% missing): {drop_cols}")

for col in df.columns:
    if df[col].isna().any():
        if pd.api.types.is_numeric_dtype(df[col]):
            df[col] = df[col].fillna(df[col].median())
        else:
            df[col] = df[col].fillna(df[col].mode()[0])
log(f"[MISSING] remaining nulls = {int(df.isna().sum().sum())}\n")

# Keep a copy for before/after outlier plots
before_outliers = df.copy()

# ---------------------------------------------------------------- 4. OUTLIERS (IQR, winsorize/cap)
# Only cap columns where extremes are statistical noise. Natural-range columns
# like age are legitimate (a 70-year-old is not an error), so they are skipped.
CAP_COLS = ["fare"]
num_cols = [c for c in CAP_COLS if c in df.columns]
for col in num_cols:
    q1, q3 = df[col].quantile([0.25, 0.75])
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    n_out = ((df[col] < lo) | (df[col] > hi)).sum()
    lo = max(lo, df[col].min())          # never invent values below the observed min
    df[col] = df[col].clip(lo, hi)
    log(f"[OUTLIERS] {col}: {n_out} values outside [{lo:.2f}, {hi:.2f}] -> capped")

# ---------------------------------------------------------------- 5. FEATURE ENGINEERING
if {"sibsp", "parch"}.issubset(df.columns):
    df["family_size"] = df["sibsp"] + df["parch"] + 1
if "age" in df.columns:
    df["age_group"] = pd.cut(df["age"], [0, 12, 18, 35, 60, 120],
                             labels=["Child", "Teen", "Young Adult", "Adult", "Senior"])
for c in df.select_dtypes(include=["object", "string"]).columns:
    df[c] = df[c].astype(str).str.strip().str.title()

df.to_csv("cleaned_data.csv", index=False)
log(f"\n[DONE] cleaned shape = {df.shape} -> cleaned_data.csv")

# ---------------------------------------------------------------- 6. DASHBOARD
fig = plt.figure(figsize=(18, 14))
fig.suptitle("Titanic Dataset - Cleaning & Insights Dashboard",
             fontsize=22, fontweight="bold", y=0.98)
gs = fig.add_gridspec(3, 3, hspace=0.4, wspace=0.28)

# (a) Missing values before
ax = fig.add_subplot(gs[0, 0])
m = miss_pct[miss_pct > 0].sort_values()
ax.barh(m.index, m.values, color="#c44e52")
ax.set_title("Missing values (% , raw data)")
ax.set_xlabel("%")

# (b) Fare outliers before vs after
ax = fig.add_subplot(gs[0, 1])
tmp = pd.DataFrame({"Before": before_outliers["fare"], "After": df["fare"]})
sns.boxplot(data=tmp, ax=ax, palette=["#c44e52", "#55a868"])
ax.set_title("Fare: outliers before vs after capping")

# (c) Survival overall
ax = fig.add_subplot(gs[0, 2])
s = df["survived"].value_counts().sort_index()
ax.pie(s.values, labels=["Died", "Survived"], autopct="%1.1f%%",
       colors=["#c44e52", "#55a868"], startangle=90, wedgeprops=dict(width=0.45))
ax.set_title("Overall survival")

# (d) Survival by sex & class
ax = fig.add_subplot(gs[1, 0])
sns.barplot(data=df, x="pclass", y="survived", hue="sex", ax=ax, errorbar=None)
ax.set_title("Survival rate by class & sex")
ax.set_ylabel("Survival rate")
ax.set_xlabel("Passenger class")

# (e) Age distribution by survival
ax = fig.add_subplot(gs[1, 1])
sns.histplot(data=df, x="age", hue="survived", kde=True, bins=25, ax=ax,
             palette=["#c44e52", "#55a868"])
ax.set_title("Age distribution by survival")

# (f) Survival by age group
ax = fig.add_subplot(gs[1, 2])
sns.barplot(data=df, x="age_group", y="survived", ax=ax, errorbar=None, color="#4c72b0")
ax.set_title("Survival rate by age group")
ax.set_ylabel("Survival rate")
ax.tick_params(axis="x", rotation=25)

# (g) Fare by class
ax = fig.add_subplot(gs[2, 0])
sns.violinplot(data=df, x="pclass", y="fare", ax=ax, inner="quartile", color="#8172b2")
ax.set_title("Fare distribution by class")

# (h) Family size vs survival
ax = fig.add_subplot(gs[2, 1])
sns.pointplot(data=df, x="family_size", y="survived", ax=ax, errorbar=None, color="#dd8452")
ax.set_title("Survival rate by family size")

# (i) Correlation heatmap
ax = fig.add_subplot(gs[2, 2])
corr = df[["survived", "pclass", "age", "fare", "family_size"]].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax, cbar=False)
ax.set_title("Correlation heatmap")

plt.savefig("dashboard.png", dpi=150, bbox_inches="tight")
log("[VIZ] saved dashboard.png")

# ---------------------------------------------------------------- 7. KEY INSIGHTS
female = df.groupby("sex")["survived"].mean()
byclass = df.groupby("pclass")["survived"].mean()
log("\n=== KEY INSIGHTS ===")
log(f"1. Women survived at {female['Female']:.0%} vs men at {female['Male']:.0%}.")
log(f"2. 1st class survival {byclass[1]:.0%} vs 3rd class {byclass[3]:.0%}.")
log(f"3. Children (<=12) survival: {df[df.age_group=='Child'].survived.mean():.0%}.")
log(f"4. Fare is strongly tied to class (corr fare~pclass = {corr.loc['pclass','fare']:.2f}).")
log("5. Mid-sized families (2-4) fared better than solo travellers or very large families.")

with open("cleaning_report.txt", "w") as f:
    f.write("\n".join(report))
